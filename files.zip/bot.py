import os
import re
import json
import logging
from datetime import datetime
from pathlib import Path
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
import anthropic

# ─── Конфигурация ───────────────────────────────────────────────
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN", "8877144729:AAFcq2MBfeqPCuo9DPAK2qaG_2Al4aHccp8")
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "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")
OBSIDIAN_PATH = os.getenv("OBSIDIAN_PATH", os.path.expanduser("~/Library/Mobile Documents/iCloud~md~obsidian/Documents"))

# ─── Логирование ────────────────────────────────────────────────
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

# ─── Клиент Anthropic ───────────────────────────────────────────
claude = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)

# ─── Хранилище истории и режимов ────────────────────────────────
user_history: dict[int, list] = {}
user_mode: dict[int, str] = {}

MODES = {
    "🎓 Учёба": "study",
    "🚢 СПГ / Работа": "spg",
    "🎨 Творчество": "creative",
    "💬 Общий": "general",
}

MODE_PROMPTS = {
    "study": "Сейчас ты помогаешь с учёбой на геологическом факультете МГУ. Фокус на геологии, минералогии, петрографии, геохимии. Объясняй чётко, используй термины, предлагай мнемоники и схемы для запоминания.",
    "spg": "Сейчас ты помогаешь с работой логиста по оптимизации морских перевозок СПГ в крупной нефтегазовой компании. Помогай с SPA (shipping point agreements), маршрутами, документацией, расчётами, форматированием заметок в Obsidian.",
    "creative": "Сейчас ты помогаешь с творческими проектами — искусство, идеи, вдохновение, новые технологии. Будь креативным, вдохновляющим, предлагай нестандартные идеи.",
    "general": "Ты универсальный персональный ассистент.",
}

SYSTEM_BASE = """Ты персональный ИИ-ассистент. Твой пользователь:
- Студент геологического факультета МГУ
- Логист по оптимизации морских перевозок СПГ в крупной нефтегазовой компании  
- Творческая личность, интересуется искусством и новыми технологиями
- Использует Obsidian для заметок (хранится в iCloud)
- Живёт в Нидерландах (Лелистад), учится в Москве

Отвечай по-русски, кратко и по делу. Если нужно сохранить заметку — используй команду /save.
Когда сохраняешь заметку в Obsidian — предложи подходящий путь к файлу на основе контекста."""

# ─── Определение пути для заметки ───────────────────────────────
def get_note_path(text: str, mode: str) -> str:
    today = datetime.now().strftime("%Y-%m-%d")
    
    mode_folders = {
        "study": "📚 Геология МГУ/Заметки",
        "spg": "🚢 СПГ Работа/Заметки",
        "creative": "🎨 Творчество/Идеи",
        "general": "📥 Входящие",
    }
    
    folder = mode_folders.get(mode, "📥 Входящие")
    # Берём первые 40 символов текста как название файла
    title = re.sub(r'[^\w\s-]', '', text[:40]).strip().replace(' ', '_')
    return f"{folder}/{today}_{title}.md"

# ─── Сохранение заметки в Obsidian ──────────────────────────────
def save_to_obsidian(text: str, path: str, mode: str) -> str:
    try:
        full_path = Path(OBSIDIAN_PATH) / path
        full_path.parent.mkdir(parents=True, exist_ok=True)
        
        today = datetime.now().strftime("%Y-%m-%d %H:%M")
        mode_names = {"study": "Учёба", "spg": "СПГ/Работа", "creative": "Творчество", "general": "Общее"}
        
        content = f"""---
created: {today}
tags: [{mode_names.get(mode, 'общее')}]
source: telegram-bot
---

# {text[:60]}

{text}
"""
        full_path.write_text(content, encoding="utf-8")
        return str(full_path)
    except Exception as e:
        logger.error(f"Ошибка сохранения: {e}")
        return None

# ─── Получение ответа от Claude ─────────────────────────────────
def ask_claude(user_id: int, message: str, mode: str) -> str:
    if user_id not in user_history:
        user_history[user_id] = []
    
    user_history[user_id].append({"role": "user", "content": message})
    
    # Ограничиваем историю последними 20 сообщениями
    history = user_history[user_id][-20:]
    
    mode_prompt = MODE_PROMPTS.get(mode, MODE_PROMPTS["general"])
    system = f"{SYSTEM_BASE}\n\n{mode_prompt}"
    
    response = claude.messages.create(
        model="claude-haiku-4-5-20251001",
        max_tokens=1000,
        system=system,
        messages=history,
    )
    
    reply = response.content[0].text
    user_history[user_id].append({"role": "assistant", "content": reply})
    
    return reply

# ─── Клавиатура режимов ─────────────────────────────────────────
def mode_keyboard():
    buttons = [[KeyboardButton(m)] for m in MODES.keys()]
    buttons.append([KeyboardButton("📝 Сохранить заметку"), KeyboardButton("🗑 Очистить историю")])
    return ReplyKeyboardMarkup(buttons, resize_keyboard=True)

# ─── Хэндлеры ───────────────────────────────────────────────────
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    user_mode[user_id] = "general"
    
    await update.message.reply_text(
        "👋 Привет! Я твой персональный ассистент.\n\n"
        "Выбери режим работы или просто напиши сообщение:",
        reply_markup=mode_keyboard()
    )

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    text = update.message.text
    mode = user_mode.get(user_id, "general")
    
    # Переключение режима
    if text in MODES:
        user_mode[user_id] = MODES[text]
        mode_name = text
        await update.message.reply_text(
            f"Режим переключён: {mode_name}",
            reply_markup=mode_keyboard()
        )
        return
    
    # Очистить историю
    if text == "🗑 Очистить историю":
        user_history[user_id] = []
        await update.message.reply_text("История очищена ✓", reply_markup=mode_keyboard())
        return
    
    # Сохранить заметку
    if text == "📝 Сохранить заметку":
        context.user_data["waiting_for_note"] = True
        await update.message.reply_text(
            "Напиши заметку — я сохраню её в Obsidian в нужную папку:",
            reply_markup=mode_keyboard()
        )
        return
    
    # Если ждём заметку
    if context.user_data.get("waiting_for_note"):
        context.user_data["waiting_for_note"] = False
        note_path = get_note_path(text, mode)
        saved_path = save_to_obsidian(text, note_path, mode)
        
        if saved_path:
            await update.message.reply_text(
                f"✅ Заметка сохранена в Obsidian\n\n"
                f"📁 `{note_path}`",
                parse_mode="Markdown",
                reply_markup=mode_keyboard()
            )
        else:
            await update.message.reply_text(
                "⚠️ Не удалось сохранить локально — бот работает на сервере.\n"
                "Скопируй текст и сохрани вручную.",
                reply_markup=mode_keyboard()
            )
        return
    
    # Обычный вопрос к Claude
    await update.message.chat.send_action("typing")
    
    try:
        reply = ask_claude(user_id, text, mode)
        await update.message.reply_text(reply, reply_markup=mode_keyboard())
    except Exception as e:
        logger.error(f"Ошибка Claude: {e}")
        await update.message.reply_text(
            "Ошибка при обращении к Claude. Попробуй ещё раз.",
            reply_markup=mode_keyboard()
        )

async def save_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    mode = user_mode.get(user_id, "general")
    
    if not context.args:
        await update.message.reply_text("Использование: /save текст заметки")
        return
    
    text = " ".join(context.args)
    note_path = get_note_path(text, mode)
    saved_path = save_to_obsidian(text, note_path, mode)
    
    if saved_path:
        await update.message.reply_text(f"✅ Сохранено: `{note_path}`", parse_mode="Markdown")
    else:
        await update.message.reply_text("⚠️ Не удалось сохранить.")

# ─── Запуск ─────────────────────────────────────────────────────
def main():
    app = Application.builder().token(TELEGRAM_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("save", save_command))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    
    logger.info("Бот запущен...")
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()
